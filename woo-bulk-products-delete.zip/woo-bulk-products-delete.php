<?php

/**
 * Plugin Name: WooCommerce Bulk Delete Products
 * Description: Delete all WooCommerce products in batches with progress tracking including images and variations
 * Version: 1.0.0
 * Author: Yasir Shabbir
 * Author URI: https://yasirshabbir.com
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class WooCommerce_Bulk_Delete_Products
{

    private $batch_size = 30; // Process 30 products at a time (fewer than orders due to complexity)
    private $log_file;

    public function __construct()
    {
        $this->log_file = WP_CONTENT_DIR . '/wc-bulk-delete-products-log.txt';

        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_ajax_delete_products_batch', array($this, 'delete_products_batch'));
        add_action('wp_ajax_get_products_count', array($this, 'get_products_count'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function add_admin_menu()
    {
        // Add to WooCommerce menu if it exists, otherwise add to Tools menu
        if (class_exists('WooCommerce') || function_exists('WC')) {
            add_submenu_page(
                'woocommerce',
                'Bulk Delete Products',
                'Bulk Delete Products',
                'manage_woocommerce',
                'wc-bulk-delete-products',
                array($this, 'admin_page')
            );
        } else {
            add_submenu_page(
                'tools.php',
                'Bulk Delete Products',
                'Bulk Delete Products',
                'manage_options',
                'wc-bulk-delete-products',
                array($this, 'admin_page')
            );
        }
    }

    public function enqueue_scripts($hook)
    {
        if ($hook !== 'woocommerce_page_wc-bulk-delete-products' && $hook !== 'tools_page_wc-bulk-delete-products') {
            return;
        }

        wp_enqueue_script('jquery');
        wp_localize_script('jquery', 'wcBulkDeleteProducts', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wc_bulk_delete_products_nonce')
        ));
    }

    public function admin_page()
    {
?>
<div class="wrap yasir-bulk-delete-wrap">
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&display=swap');

    .yasir-bulk-delete-wrap {
        font-family: 'Lato', sans-serif;
        background: #121212;
        color: #ffffff;
        padding: 20px;
        border-radius: 3px;
        margin: 20px 0;
    }

    .yasir-header {
        background: linear-gradient(135deg, #1e1e1e, #2a2a2a);
        padding: 30px;
        border-radius: 3px;
        border: 1px solid #333333;
        margin-bottom: 30px;
        text-align: center;
    }

    .yasir-header h1 {
        color: #16e791;
        font-size: 2.5em;
        margin: 0 0 10px 0;
        font-weight: 700;
    }

    .yasir-header .subtitle {
        color: #e0e0e0;
        font-size: 1.1em;
        margin: 0;
    }

    .yasir-header .brand-link {
        color: #16e791;
        text-decoration: none;
        font-weight: 400;
    }

    .yasir-header .brand-link:hover {
        text-decoration: underline;
    }

    .yasir-card {
        background: #1e1e1e;
        border: 1px solid #333333;
        border-radius: 3px;
        padding: 30px;
        margin-bottom: 20px;
    }

    .yasir-card h2 {
        color: #16e791;
        margin-top: 0;
        font-size: 1.5em;
    }

    .yasir-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .yasir-stat-card {
        background: #2a2a2a;
        border: 1px solid #444444;
        border-radius: 3px;
        padding: 20px;
        text-align: center;
    }

    .yasir-stat-number {
        font-size: 2em;
        font-weight: 700;
        color: #16e791;
        margin: 0 0 5px 0;
    }

    .yasir-stat-label {
        color: #e0e0e0;
        font-size: 0.9em;
        margin: 0;
    }

    .yasir-button {
        background: #16e791;
        color: #121212;
        border: none;
        padding: 15px 30px;
        border-radius: 3px;
        font-size: 1.1em;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s ease;
        font-family: 'Lato', sans-serif;
        margin-right: 10px;
    }

    .yasir-button:hover {
        background: #14d182;
        transform: translateY(-2px);
    }

    .yasir-button:disabled {
        background: #6c757d;
        color: #e0e0e0;
        cursor: not-allowed;
        transform: none;
    }

    .yasir-button.danger {
        background: #dc3545;
        color: #ffffff;
    }

    .yasir-button.danger:hover {
        background: #c82333;
    }

    .yasir-progress-container {
        margin: 20px 0;
        display: none;
    }

    .yasir-progress-bar {
        width: 100%;
        height: 20px;
        background: #2a2a2a;
        border-radius: 3px;
        overflow: hidden;
        border: 1px solid #444444;
    }

    .yasir-progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #16e791, #14d182);
        width: 0%;
        transition: width 0.3s ease;
    }

    .yasir-progress-text {
        text-align: center;
        margin-top: 10px;
        color: #e0e0e0;
    }

    .yasir-log {
        background: #121212;
        border: 1px solid #333333;
        border-radius: 3px;
        padding: 20px;
        max-height: 300px;
        overflow-y: auto;
        font-family: 'Courier New', monospace;
        font-size: 0.9em;
        color: #e0e0e0;
        white-space: pre-wrap;
    }

    .yasir-warning {
        background: #ffc107;
        color: #121212;
        padding: 15px;
        border-radius: 3px;
        margin: 20px 0;
        font-weight: 700;
    }

    .yasir-success {
        background: #28a745;
        color: #ffffff;
        padding: 15px;
        border-radius: 3px;
        margin: 20px 0;
        font-weight: 700;
    }

    .yasir-error {
        background: #dc3545;
        color: #ffffff;
        padding: 15px;
        border-radius: 3px;
        margin: 20px 0;
        font-weight: 700;
    }

    .yasir-info {
        background: #17a2b8;
        color: #ffffff;
        padding: 15px;
        border-radius: 3px;
        margin: 20px 0;
        font-weight: 700;
    }

    .deletion-options {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 15px;
        margin: 20px 0;
    }

    .option-card {
        background: #2a2a2a;
        border: 1px solid #444444;
        border-radius: 3px;
        padding: 15px;
    }

    .option-card label {
        display: flex;
        align-items: center;
        color: #e0e0e0;
        font-weight: 600;
        cursor: pointer;
    }

    .option-card input[type="checkbox"] {
        margin-right: 10px;
        transform: scale(1.2);
        accent-color: #16e791;
    }

    .option-description {
        font-size: 0.9em;
        color: #b0b0b0;
        margin-top: 5px;
        margin-left: 25px;
    }

    /* Loading spinner styles */
    .yasir-loading-spinner {
        display: inline-block;
        width: 16px;
        height: 16px;
        border: 2px solid #ffffff;
        border-radius: 50%;
        border-top-color: transparent;
        animation: yasir-spin 1s ease-in-out infinite;
        margin-right: 8px;
    }

    @keyframes yasir-spin {
        to {
            transform: rotate(360deg);
        }
    }

    .yasir-button.loading {
        opacity: 0.7;
        cursor: not-allowed;
        pointer-events: none;
    }

    .yasir-stats.loading .yasir-stat-number {
        opacity: 0.5;
        position: relative;
        transition: opacity 0.3s ease;
    }

    .yasir-stats.loading .yasir-stat-number::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 16px;
        height: 16px;
        margin: -8px 0 0 -8px;
        border: 2px solid #16e791;
        border-radius: 50%;
        border-top-color: transparent;
        animation: yasir-spin 1s ease-in-out infinite;
    }

    .yasir-stat-number {
        transition: opacity 0.3s ease;
    }
    </style>

    <div class="yasir-header">
        <h1>WooCommerce Bulk Delete Products</h1>
        <p class="subtitle">Developed by <a href="https://yasirshabbir.com" class="brand-link" target="_blank">Yasir
                Shabbir</a></p>
    </div>

    <div class="yasir-card">
        <h2>Product Statistics</h2>
        <div class="yasir-stats">
            <div class="yasir-stat-card">
                <div class="yasir-stat-number" id="total-products">Loading...</div>
                <div class="yasir-stat-label">Total Products</div>
            </div>
            <div class="yasir-stat-card">
                <div class="yasir-stat-number" id="total-variations">Loading...</div>
                <div class="yasir-stat-label">Product Variations</div>
            </div>
            <div class="yasir-stat-card">
                <div class="yasir-stat-number" id="processed-products">0</div>
                <div class="yasir-stat-label">Processed</div>
            </div>
            <div class="yasir-stat-card">
                <div class="yasir-stat-number" id="remaining-products">Loading...</div>
                <div class="yasir-stat-label">Remaining</div>
            </div>
        </div>
    </div>

    <div class="yasir-card">
        <h2>Deletion Options</h2>
        <div class="yasir-info">
            📋 Configure what data should be deleted along with the products. All options are recommended for complete
            cleanup.
        </div>

        <div class="deletion-options">
            <div class="option-card">
                <label>
                    <input type="checkbox" id="delete-images" checked>
                    Delete Product Images
                </label>
                <div class="option-description">Remove all product images from media library</div>
            </div>
            <div class="option-card">
                <label>
                    <input type="checkbox" id="delete-variations" checked>
                    Delete Product Variations
                </label>
                <div class="option-description">Remove all product variations and their data</div>
            </div>
            <div class="option-card">
                <label>
                    <input type="checkbox" id="delete-meta" checked>
                    Delete Product Meta
                </label>
                <div class="option-description">Remove all custom fields and meta data</div>
            </div>
            <div class="option-card">
                <label>
                    <input type="checkbox" id="delete-terms" checked>
                    Delete Product Terms
                </label>
                <div class="option-description">Remove categories, tags, and attributes relationships</div>
            </div>
            <div class="option-card">
                <label>
                    <input type="checkbox" id="only-without-sku">
                    Delete Only Products Without SKU
                </label>
                <div class="option-description">Only delete products that have empty or missing SKU values</div>
            </div>
        </div>
    </div>

    <div class="yasir-card">
        <h2>Bulk Delete Operations</h2>
        <div class="yasir-warning" id="warning-message">
            ⚠️ WARNING: This action will permanently delete ALL WooCommerce products including images, variations, and
            all related data. This cannot be undone. Please backup your database before proceeding.
        </div>

        <button id="start-delete" class="yasir-button danger">Delete All Products</button>
        <button id="refresh-count" class="yasir-button">Refresh Count</button>

        <div class="yasir-progress-container" id="progress-container">
            <div class="yasir-progress-bar">
                <div class="yasir-progress-fill" id="progress-fill"></div>
            </div>
            <div class="yasir-progress-text" id="progress-text">0% Complete</div>
        </div>
    </div>

    <div class="yasir-card">
        <h2>Process Log</h2>
        <div class="yasir-log" id="process-log">Ready to start deletion process...</div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        let totalProducts = 0;
        let totalVariations = 0;
        let processedProducts = 0;
        let isProcessing = false;

        // Get initial product count with loading state
        logMessage('Initializing WooCommerce Bulk Delete Products plugin...');
        getProductsCount();

        $('#refresh-count').on('click', function() {
            if (!$(this).hasClass('loading')) {
                getProductsCount();
            }
        });

        $('#only-without-sku').on('change', function() {
            getProductsCount();
            updateWarningMessage();
        });

        function updateWarningMessage() {
            const onlyWithoutSku = $('#only-without-sku').is(':checked');
            const warningElement = $('#warning-message');
            const buttonElement = $('#start-delete');

            if (onlyWithoutSku) {
                warningElement.html(
                    '⚠️ WARNING: This action will permanently delete all WooCommerce products WITHOUT SKU including images, variations, and all related data. This cannot be undone. Please backup your database before proceeding.'
                );
                buttonElement.text('Delete Products Without SKU');
            } else {
                warningElement.html(
                    '⚠️ WARNING: This action will permanently delete ALL WooCommerce products including images, variations, and all related data. This cannot be undone. Please backup your database before proceeding.'
                );
                buttonElement.text('Delete All Products');
            }
        }

        $('#start-delete').on('click', function() {
            const onlyWithoutSku = $('#only-without-sku').is(':checked');
            const warningMessage = onlyWithoutSku ?
                'Are you sure you want to delete all products WITHOUT SKU and their data? This cannot be undone!' :
                'Are you absolutely sure you want to delete ALL products and their data? This cannot be undone!';

            const finalWarningMessage = onlyWithoutSku ?
                'Last chance! This will permanently delete all WooCommerce products WITHOUT SKU, images, variations, and related data. Continue?' :
                'Last chance! This will permanently delete all WooCommerce products, images, variations, and related data. Continue?';

            if (!confirm(warningMessage)) {
                return;
            }

            if (!confirm(finalWarningMessage)) {
                return;
            }

            startDeletion();
        });

        function getProductsCount() {
            const onlyWithoutSku = $('#only-without-sku').is(':checked');
            const refreshButton = $('#refresh-count');
            const statsContainer = $('.yasir-stats');

            // Start loading state
            refreshButton.addClass('loading');
            refreshButton.html('<span class="yasir-loading-spinner"></span>Refreshing...');
            statsContainer.addClass('loading');

            // Set loading text for stats
            $('#total-products').text('Loading...');
            $('#total-variations').text('Loading...');
            $('#remaining-products').text('Loading...');

            $.ajax({
                url: wcBulkDeleteProducts.ajax_url,
                type: 'POST',
                data: {
                    action: 'get_products_count',
                    nonce: wcBulkDeleteProducts.nonce,
                    only_without_sku: onlyWithoutSku
                },
                success: function(response) {
                    if (response.success) {
                        totalProducts = response.data.products;
                        totalVariations = response.data.variations;
                        $('#total-products').text(totalProducts);
                        $('#total-variations').text(totalVariations);
                        $('#remaining-products').text(totalProducts - processedProducts);

                        const skuFilterText = onlyWithoutSku ? ' (without SKU)' : '';
                        logMessage('Total products found: ' + totalProducts + skuFilterText +
                            ' (Variations: ' +
                            totalVariations + ')');
                    } else {
                        logMessage('Error getting product count: ' + (response.data ? response.data
                            .message : 'Unknown error'));
                        // Set error state
                        $('#total-products').text('Error');
                        $('#total-variations').text('Error');
                        $('#remaining-products').text('Error');
                    }
                },
                error: function(xhr, status, error) {
                    logMessage('AJAX error getting product count: ' + error);
                    // Set error state
                    $('#total-products').text('Error');
                    $('#total-variations').text('Error');
                    $('#remaining-products').text('Error');
                },
                complete: function() {
                    // End loading state
                    refreshButton.removeClass('loading');
                    refreshButton.html('Refresh Count');
                    statsContainer.removeClass('loading');
                }
            });
        }

        function startDeletion() {
            if (isProcessing) return;

            isProcessing = true;
            processedProducts = 0;

            $('#start-delete').prop('disabled', true);
            $('#progress-container').show();

            // Get deletion options
            const options = {
                delete_images: $('#delete-images').is(':checked'),
                delete_variations: $('#delete-variations').is(':checked'),
                delete_meta: $('#delete-meta').is(':checked'),
                delete_terms: $('#delete-terms').is(':checked'),
                only_without_sku: $('#only-without-sku').is(':checked')
            };

            logMessage('Starting bulk deletion process with options: ' + JSON.stringify(options));
            processBatch(options);
        }

        function processBatch(options) {
            $.ajax({
                url: wcBulkDeleteProducts.ajax_url,
                type: 'POST',
                data: {
                    action: 'delete_products_batch',
                    nonce: wcBulkDeleteProducts.nonce,
                    options: options
                },
                success: function(response) {
                    if (response.success) {
                        processedProducts += response.data.deleted;
                        updateProgress();
                        logMessage('Batch processed: ' + response.data.deleted +
                            ' products deleted (' + response.data.images_deleted + ' images, ' +
                            response.data.variations_deleted + ' variations)');

                        if (response.data.remaining > 0) {
                            // Continue processing
                            setTimeout(function() {
                                processBatch(options);
                            }, 1500); // 1.5 second delay between batches (longer due to complexity)
                        } else {
                            // All done
                            completeDeletion();
                        }
                    } else {
                        logMessage('Error: ' + (response.data ? response.data.message :
                            'Unknown error'));
                        completeDeletion();
                    }
                },
                error: function(xhr, status, error) {
                    logMessage('AJAX error occurred: ' + error);
                    completeDeletion();
                }
            });
        }

        function updateProgress() {
            const percentage = totalProducts > 0 ? Math.round((processedProducts / totalProducts) * 100) : 0;
            $('#progress-fill').css('width', percentage + '%');
            $('#progress-text').text(percentage + '% Complete (' + processedProducts + '/' + totalProducts +
                ')');
            $('#processed-products').text(processedProducts);
            $('#remaining-products').text(totalProducts - processedProducts);
        }

        function completeDeletion() {
            isProcessing = false;
            $('#start-delete').prop('disabled', false);

            if (processedProducts === totalProducts) {
                logMessage(
                    '✅ Deletion completed successfully! All products and related data have been removed.');
                showMessage('All products have been successfully deleted!', 'success');
            } else {
                logMessage('⚠️ Deletion completed with some remaining products.');
                showMessage('Deletion process completed. Check logs for details.', 'warning');
            }

            getProductsCount();
        }

        function logMessage(message) {
            const timestamp = new Date().toLocaleTimeString();
            const logEntry = '[' + timestamp + '] ' + message + '\n';
            $('#process-log').append(logEntry);
            $('#process-log').scrollTop($('#process-log')[0].scrollHeight);
        }

        function showMessage(message, type) {
            const messageDiv = $('<div class="yasir-' + type + '">' + message + '</div>');
            $('.yasir-card').first().after(messageDiv);
            setTimeout(function() {
                messageDiv.fadeOut(500, function() {
                    $(this).remove();
                });
            }, 5000);
        }
    });
    </script>
</div>
<?php
    }

    public function get_products_count()
    {
        check_ajax_referer('wc_bulk_delete_products_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        global $wpdb;

        $only_without_sku = isset($_POST['only_without_sku']) && ($_POST['only_without_sku'] === 'true' || $_POST['only_without_sku'] === true);

        if ($only_without_sku) {
            // Count products without SKU (empty or missing _sku meta)
            $products_count = $wpdb->get_var(
                "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                 LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_sku'
                 WHERE p.post_type = 'product' 
                 AND (pm.meta_value IS NULL OR pm.meta_value = '')"
            );
        } else {
            // Count all products
            $products_count = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} 
                 WHERE post_type = 'product'"
            );
        }

        // Count variations (always all variations for now)
        $variations_count = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
             WHERE post_type = 'product_variation'"
        );

        $filter_text = $only_without_sku ? " (without SKU filter applied)" : " (all products)";
        $this->log_message("Product count requested: Products: {$products_count}{$filter_text}, Variations: {$variations_count}");

        wp_send_json_success(array(
            'products' => intval($products_count),
            'variations' => intval($variations_count)
        ));
    }

    public function delete_products_batch()
    {
        check_ajax_referer('wc_bulk_delete_products_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        global $wpdb;

        // Get deletion options
        $options = isset($_POST['options']) ? $_POST['options'] : array();
        $delete_images = isset($options['delete_images']) ? $options['delete_images'] : true;
        $delete_variations = isset($options['delete_variations']) ? $options['delete_variations'] : true;
        $delete_meta = isset($options['delete_meta']) ? $options['delete_meta'] : true;
        $delete_terms = isset($options['delete_terms']) ? $options['delete_terms'] : true;
        $only_without_sku = isset($options['only_without_sku']) && ($options['only_without_sku'] === 'true' || $options['only_without_sku'] === true);

        $this->log_message("Debug: Received options: " . json_encode($options));
        $this->log_message("Debug: Processed only_without_sku: " . ($only_without_sku ? 'true' : 'false'));

        // Get a batch of product IDs based on SKU filter
        if ($only_without_sku) {
            // Get products without SKU
            $product_ids = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT p.ID FROM {$wpdb->posts} p
                     LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_sku'
                     WHERE p.post_type = 'product' 
                     AND (pm.meta_value IS NULL OR pm.meta_value = '')
                     LIMIT %d",
                    $this->batch_size
                )
            );
        } else {
            // Get all products
            $product_ids = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts} 
                     WHERE post_type = 'product' 
                     LIMIT %d",
                    $this->batch_size
                )
            );
        }

        $deleted_count = 0;
        $images_deleted = 0;
        $variations_deleted = 0;

        $this->log_message("Debug: Found " . count($product_ids) . " products to process. SKU filter: " . ($only_without_sku ? 'enabled' : 'disabled'));

        if (!empty($product_ids)) {
            foreach ($product_ids as $product_id) {
                try {
                    $this->log_message("Debug: Processing product ID: {$product_id}");
                    
                    // Get product images before deletion
                    $image_ids = array();
                    if ($delete_images) {
                        $image_ids = $this->get_product_image_ids($product_id);
                    }

                    // Get product variations before deletion
                    $variation_ids = array();
                    if ($delete_variations) {
                        $variation_ids = $wpdb->get_col($wpdb->prepare(
                            "SELECT ID FROM {$wpdb->posts} WHERE post_parent = %d AND post_type = 'product_variation'",
                            $product_id
                        ));
                    }

                    // Delete using WooCommerce function if available
                    $result = false;
                    if (function_exists('wc_delete_product')) {
                        $result = wc_delete_product($product_id, true);
                        $this->log_message("Debug: wc_delete_product result for {$product_id}: " . ($result ? 'success' : 'failed'));
                    }
                    
                    // If WooCommerce deletion failed or function doesn't exist, use WordPress function
                    if (!$result) {
                        $result = wp_delete_post($product_id, true);
                        $this->log_message("Debug: wp_delete_post result for {$product_id}: " . ($result ? 'success' : 'failed'));
                    }
                    
                    if ($result) {
                        $deleted_count++;
                    } else {
                        $this->log_message("Warning: Failed to delete product {$product_id}");
                    }

                    // Delete variations if requested
                    if ($delete_variations && !empty($variation_ids)) {
                        foreach ($variation_ids as $variation_id) {
                            wp_delete_post($variation_id, true);
                            $variations_deleted++;
                        }
                    }

                    // Delete product images if requested
                    if ($delete_images && !empty($image_ids)) {
                        foreach ($image_ids as $image_id) {
                            wp_delete_attachment($image_id, true);
                            $images_deleted++;
                        }
                    }

                    // Delete product meta if requested
                    if ($delete_meta) {
                        $wpdb->delete($wpdb->postmeta, array('post_id' => $product_id));
                    }

                    // Delete product terms if requested
                    if ($delete_terms) {
                        $wpdb->delete($wpdb->term_relationships, array('object_id' => $product_id));
                    }
                } catch (Exception $e) {
                    $this->log_message("Error deleting product {$product_id}: " . $e->getMessage());
                    continue;
                }
            }
        }

        // Get remaining count based on SKU filter
        if ($only_without_sku) {
            $remaining = $wpdb->get_var(
                "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                 LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_sku'
                 WHERE p.post_type = 'product' 
                 AND (pm.meta_value IS NULL OR pm.meta_value = '')"
            );
        } else {
            $remaining = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} 
                 WHERE post_type = 'product'"
            );
        }

        $filter_text = $only_without_sku ? " (SKU filter: without SKU)" : "";
        $this->log_message("Batch processed: {$deleted_count} products deleted{$filter_text}, {$images_deleted} images deleted, {$variations_deleted} variations deleted, {$remaining} remaining");

        wp_send_json_success(array(
            'deleted' => $deleted_count,
            'images_deleted' => $images_deleted,
            'variations_deleted' => $variations_deleted,
            'remaining' => intval($remaining)
        ));
    }

    private function get_product_image_ids($product_id)
    {
        global $wpdb;

        $image_ids = array();

        // Get featured image
        $featured_image = get_post_thumbnail_id($product_id);
        if ($featured_image) {
            $image_ids[] = $featured_image;
        }

        // Get gallery images
        $gallery_images = get_post_meta($product_id, '_product_image_gallery', true);
        if ($gallery_images) {
            $gallery_array = explode(',', $gallery_images);
            $image_ids = array_merge($image_ids, $gallery_array);
        }

        // Get variation images
        $variation_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_parent = %d AND post_type = 'product_variation'",
            $product_id
        ));

        foreach ($variation_ids as $variation_id) {
            $variation_image = get_post_thumbnail_id($variation_id);
            if ($variation_image) {
                $image_ids[] = $variation_image;
            }
        }

        return array_unique(array_filter($image_ids));
    }

    private function log_message($message)
    {
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[{$timestamp}] {$message}" . PHP_EOL;
        file_put_contents($this->log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }
}

// Initialize the plugin
function init_woocommerce_bulk_delete_products()
{
    if (class_exists('WooCommerce') || in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        new WooCommerce_Bulk_Delete_Products();
    } else {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>WooCommerce Bulk Delete Products requires WooCommerce to be installed and active.</p></div>';
        });
    }
}

// Hook into plugins_loaded to ensure WooCommerce is loaded first
add_action('plugins_loaded', 'init_woocommerce_bulk_delete_products');
?>